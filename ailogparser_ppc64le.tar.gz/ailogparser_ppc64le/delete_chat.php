<?php
require __DIR__ . '/db.php';
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit(json_encode(['error' => 'POST required']));
}

$scanId = (int)($_POST['scan_id'] ?? 0);
if ($scanId <= 0) {
    http_response_code(400);
    exit(json_encode(['error' => 'scan_id required']));
}

db()->prepare("DELETE FROM chat_messages WHERE scan_id = ?")->execute([$scanId]);
echo json_encode(['ok' => true]);
