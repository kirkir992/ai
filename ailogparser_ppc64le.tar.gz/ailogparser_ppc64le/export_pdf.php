<?php
require __DIR__ . '/vendor/autoload.php';
require __DIR__ . '/db.php';

use Dompdf\Dompdf;
use Dompdf\Options;

$id = $_GET['id'] ?? null;

if ($id) {
    $stmt = db()->prepare("SELECT * FROM scans WHERE id = ?");
    $stmt->execute([(int)$id]);
    $rows = $stmt->fetchAll();
    $title = "AI Log Analysis Report — scan #" . (int)$id;
} else {
    $rows = db()->query("SELECT * FROM scans ORDER BY id DESC")->fetchAll();
    $title = "AI Log Analysis Report — wszystkie skany";
}

$totalScans  = count($rows);
$totalErrors = array_sum(array_map(fn($r) => (int)($r['errors_count'] ?? 0), $rows));
$totalHigh   = count(array_filter($rows, fn($r) => ($r['severity'] ?? '') === 'HIGH'));
$totalMedium = count(array_filter($rows, fn($r) => ($r['severity'] ?? '') === 'MEDIUM'));
$totalLow    = count(array_filter($rows, fn($r) => ($r['severity'] ?? '') === 'LOW'));

$e = fn($s) => htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');

$html = <<<HTML
<!DOCTYPE html>
<html><head><meta charset="utf-8">
<style>
  body { font-family: DejaVu Sans, sans-serif; font-size: 11pt; color:#111; }
  h1 { color:#1e3a8a; border-bottom:2px solid #1e3a8a; padding-bottom:6px; }
  h2 { color:#374151; margin-top:22px; border-bottom:1px solid #e5e7eb; padding-bottom:4px; }
  h3 { color:#1f2937; margin-top:18px; }
  table { width:100%; border-collapse:collapse; margin-top:8px; }
  th { background:#1e3a8a; color:#fff; padding:6px; text-align:left; font-size:10pt; }
  td { padding:6px; border-bottom:1px solid #e5e7eb; vertical-align:top; font-size:10pt; }
  .summary { background:#eff6ff; padding:10px; border-left:4px solid #2563eb; margin:10px 0; }
  .findings { background:#f9fafb; padding:10px; border-radius:6px;
              white-space:pre-wrap; font-size:10pt; border:1px solid #e5e7eb; }
  .reco { background:#f0fdf4; padding:10px; border-left:4px solid #16a34a;
          margin:10px 0; border-radius:6px; font-size:10pt; }
  .reco ol { margin:6px 0 0 18px; padding:0; }
  .reco li { margin-bottom:4px; }
  .metric-box { display:inline-block; width:22%; margin:1%; padding:10px; text-align:center;
                border:1px solid #e5e7eb; border-radius:6px; }
  .metric-num { font-size:20pt; font-weight:bold; }
  .metric-lbl { font-size:9pt; color:#6b7280; }
  .HIGH   { color:#dc2626; font-weight:bold; }
  .MEDIUM { color:#d97706; font-weight:bold; }
  .LOW    { color:#16a34a; font-weight:bold; }
  .meta { color:#6b7280; font-size:9pt; }
</style></head><body>

<h1>{$e($title)}</h1>
<p class="meta"><b>Wygenerowano:</b> {$e(date('Y-m-d H:i:s'))}</p>

<h2>Podsumowanie</h2>
<div class="summary">
  Przeskanowano <b>{$totalScans}</b> plików. Łącznie wykryto <b>{$totalErrors}</b> zdarzeń:
  <span class="HIGH">{$totalHigh} krytycznych</span>,
  <span class="MEDIUM">{$totalMedium} ostrzeżeń</span>,
  <span class="LOW">{$totalLow} o niskim priorytecie</span>.
</div>

<div>
  <div class="metric-box"><div class="metric-num">{$totalScans}</div><div class="metric-lbl">SKANÓW</div></div>
  <div class="metric-box"><div class="metric-num HIGH">{$totalHigh}</div><div class="metric-lbl">KRYTYCZNE</div></div>
  <div class="metric-box"><div class="metric-num MEDIUM">{$totalMedium}</div><div class="metric-lbl">OSTRZEŻENIA</div></div>
  <div class="metric-box"><div class="metric-num LOW">{$totalLow}</div><div class="metric-lbl">NISKIE</div></div>
</div>

<h2>Wykryte incydenty</h2>
<table>
<tr><th>ID</th><th>Host</th><th>Plik</th><th>Data</th><th>Model AI</th><th>Waga</th><th>Błędów</th></tr>
HTML;

if ($totalScans === 0) {
    $html .= '<tr><td colspan="7" style="text-align:center;color:#9ca3af;">Brak skanów</td></tr>';
} else {
    foreach ($rows as $r) {
        $sev = $r['severity'] ?? 'LOW';
        $html .= '<tr>'
            . '<td>' . $e($r['id']) . '</td>'
            . '<td>' . $e($r['host'] ?? '—') . '</td>'
            . '<td>' . $e($r['filename']) . '</td>'
            . '<td>' . $e($r['scan_time']) . '</td>'
            . '<td>' . $e($r['model'] ?? '—') . '</td>'
            . '<td class="' . $e($sev) . '">' . $e($sev) . '</td>'
            . '<td>' . (int)($r['errors_count'] ?? 0) . '</td>'
            . '</tr>';
    }
}
$html .= '</table>';

if ($totalScans > 0) {
    $html .= '<h2>Szczegóły analizy</h2>';
    foreach ($rows as $r) {
        $sev = $r['severity'] ?? 'LOW';
        $html .= '<h3>#' . $e($r['id']) . ' — ' . $e($r['filename'])
               . ' <span class="' . $e($sev) . '">[' . $e($sev) . ']</span></h3>';
        $html .= '<p class="meta"><b>Host:</b> ' . $e($r['host'] ?? '—')
               . ' | <b>Model:</b> ' . $e($r['model'] ?? '—')
               . ' | <b>Data:</b> ' . $e($r['scan_time']) . '</p>';

        if (!empty($r['summary'])) {
            $html .= '<div class="summary"><b>Podsumowanie AI:</b><br>'
                   . nl2br($e($r['summary'])) . '</div>';
        }
        if (!empty($r['findings'])) {
            $html .= '<div class="findings"><b>Wykryte problemy:</b><br>'
                   . nl2br($e($r['findings'])) . '</div>';
        }
        if (!empty($r['recommendations'])) {
            $html .= '<div class="reco"><b>✅ Co sprawdzić / jak naprawić:</b><ol>';
            foreach (preg_split('/\r?\n/', $r['recommendations']) as $line) {
                $line = trim($line);
                if ($line !== '') $html .= '<li>' . $e($line) . '</li>';
            }
            $html .= '</ol></div>';
        }
    }
}

$html .= '</body></html>';

$options = new Options();
$options->set('isRemoteEnabled', false);
$options->set('defaultFont', 'DejaVu Sans');

$dompdf = new Dompdf($options);
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();
$dompdf->stream(
    'ai_log_report_' . ($id ?: 'all') . '_' . date('Ymd_His') . '.pdf',
    ['Attachment' => true]
);
