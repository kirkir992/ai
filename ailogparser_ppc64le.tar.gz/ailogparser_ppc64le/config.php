<?php
// Jedyne źródło prawdy o Ollama — reszta wyprowadzana automatycznie
$ollamaUrl = getenv('OLLAMA_URL') ?: 'http://192.168.95.220:11434/api/chat';

return [
    'upload_dir'       => getenv('UPLOAD_DIR') ?: '/u01/log',
    'db_path'          => getenv('DB_PATH')    ?: '/u01/scans.db',
    'ollama_url'       => $ollamaUrl,
    'ollama_api'       => preg_replace('#/api/chat$#', '', $ollamaUrl),
    'model'            => getenv('DEFAULT_MODEL') ?: 'qwen2.5-coder:7b-instruct',
    'models_cache_ttl' => 60,   // sekundy — cache listy modeli
    'max_log_bytes'    => 12000, // ile znaków logu wysyłamy do modelu
    'request_timeout'  => 600,  // timeout na wywołanie Ollama (s)
];
