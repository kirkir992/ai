<?php
$cfg = require __DIR__ . '/config.php';
?>
<!DOCTYPE html>
<html lang="pl">
<head>
<meta charset="utf-8">
<title>AI Log Scan Dashboard</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4"></script>
<style>
  body { font-family: system-ui, sans-serif; max-width: 1200px; margin: 2rem auto;
         padding: 0 1rem; background:#f7f8fa; color:#111; }
  h1 { color:#1e3a8a; }
  h2 { color:#374151; margin-top:0; }
  h3 { color:#1f2937; margin-top:1rem; }
  .card { background:#fff; border:1px solid #e5e7eb; border-radius:10px;
          padding:1.25rem; margin:1rem 0; box-shadow:0 1px 3px rgba(0,0,0,.04); }
  .btn { background:#2563eb; color:#fff; padding:.6rem 1.2rem; border:none;
         border-radius:6px; cursor:pointer; font-size:1rem; text-decoration:none;
         display:inline-block; }
  .btn:hover { background:#1d4ed8; }
  .btn.secondary { background:#6b7280; }
  .btn.danger { background:#dc2626; }
  .btn.danger:hover { background:#b91c1c; }
  .btn.small { padding:.3rem .7rem; font-size:.85rem; }
  .btn:disabled { opacity:.5; cursor:not-allowed; }
  select, input[type=file], input[type=text], textarea {
      padding:.5rem; border:1px solid #d1d5db; border-radius:6px; font-size:.95rem;
      font-family: inherit; box-sizing: border-box; }
  select { min-width:280px; }
  input[type=text] { min-width:180px; }
  textarea { width:100%; min-height:160px; font-family: ui-monospace, monospace;
             font-size:.85rem; resize: vertical; }

  .tabs { display:flex; gap:.25rem; margin-bottom:1rem; border-bottom:2px solid #e5e7eb; }
  .tab { padding:.6rem 1.2rem; cursor:pointer; border:none; background:transparent;
         font-size:1rem; color:#6b7280; border-bottom:2px solid transparent;
         margin-bottom:-2px; }
  .tab.active { color:#2563eb; border-bottom-color:#2563eb; font-weight:600; }
  .tab-panel { display:none; }
  .tab-panel.active { display:block; }

  table { width:100%; border-collapse:collapse; margin-top:1rem; }
  th,td { text-align:left; padding:.5rem .6rem; border-bottom:1px solid #eee; }
  th { background:#f3f4f6; }
  tbody tr { cursor:pointer; }
  tbody tr:hover { background:#f9fafb; }
  tbody tr.selected { background:#eff6ff; outline:2px solid #2563eb; outline-offset:-2px; }
  .sev-HIGH   { color:#dc2626; font-weight:bold; }
  .sev-MEDIUM { color:#d97706; font-weight:bold; }
  .sev-LOW    { color:#16a34a; font-weight:bold; }
  .model-tag { background:#eef2ff; color:#3730a3; padding:.15rem .5rem;
               border-radius:6px; font-size:.85em; white-space:nowrap; }
  .host-tag { background:#ecfdf5; color:#065f46; padding:.15rem .5rem;
              border-radius:6px; font-size:.85em; white-space:nowrap;
              font-family: ui-monospace, monospace; }
  .spinner { display:none; margin-left:.5rem; color:#6b7280; font-size:.9em; }
  .status-dot { display:inline-block; width:10px; height:10px; border-radius:50%;
                margin-right:6px; }
  .status-online  { background:#16a34a; }
  .status-offline { background:#dc2626; }

  .chart-wrap { position: relative; height: 300px; max-width: 420px; margin: 0 auto; }
  .chart-header { display:flex; justify-content:space-between; align-items:center;
                  gap:1rem; flex-wrap:wrap; }
  .chart-header h2 { margin:0; }
  .chart-scope { font-size:.9em; color:#6b7280; }
  .chart-scope b { color:#111; }

  .trash { color:#dc2626; font-weight:bold; text-decoration:none; padding:0 .3rem; }
  .trash:hover { color:#7f1d1d; }

  .summary-box { background:#eff6ff; padding:10px 12px; border-left:4px solid #2563eb;
                 border-radius:6px; margin-bottom:8px; }
  .findings-list, .reco-list { margin:6px 0 0 20px; padding:0; }
  .findings-list li, .reco-list li { margin-bottom:6px; }
  .reco-list { background:#f0fdf4; border-left:4px solid #16a34a;
               padding:10px 10px 10px 30px; border-radius:6px; }

  /* Czat */
  .chat-box { margin-top:.5rem; }
  .chat-log { background:#f9fafb; border:1px solid #e5e7eb; border-radius:8px;
              padding:.75rem; height:340px; overflow-y:auto; display:flex;
              flex-direction:column; gap:.5rem; }
  .chat-empty { color:#9ca3af; font-size:.9em; text-align:center; padding:2rem 1rem; }
  .chat-msg { padding:.5rem .75rem; border-radius:8px; max-width:85%;
              white-space:pre-wrap; word-wrap:break-word; font-size:.92rem;
              line-height:1.4; }
  .chat-msg.user { background:#2563eb; color:#fff; align-self:flex-end;
                   border-bottom-right-radius:2px; }
  .chat-msg.assistant { background:#e5e7eb; color:#111; align-self:flex-start;
                        border-bottom-left-radius:2px; }
  .chat-msg.typing { background:#e5e7eb; color:#6b7280; font-style:italic;
                     align-self:flex-start; }
  .chat-input-row { display:flex; gap:.5rem; margin-top:.5rem; }
  .chat-input-row input { flex:1; }
  .chat-status { font-size:.85em; color:#6b7280; margin-top:.3rem; min-height:1.2em; }
  .chat-status.error { color:#dc2626; }

  .toast { position:fixed; bottom:20px; right:20px; background:#111827; color:#fff;
           padding:.8rem 1rem; border-radius:8px; box-shadow:0 4px 12px rgba(0,0,0,.15);
           display:none; z-index:9999; font-size:.9em; max-width:360px; }
  .toast.show { display:block; animation: fadein .2s; }
  @keyframes fadein { from { opacity:0; transform: translateY(8px); }
                      to   { opacity:1; transform: translateY(0); } }
</style>
</head>
<body>
<h1>🛡️ AI Log Scan Dashboard</h1>

<div class="card">
  <h2>Upload &amp; Scan</h2>
  <form id="uploadForm" autocomplete="off">
    <div class="tabs">
      <button type="button" class="tab active" data-tab="file">📁 Plik</button>
      <button type="button" class="tab" data-tab="paste">📋 Wklej tekst</button>
    </div>

    <div class="tab-panel active" data-panel="file">
      <input type="file" name="logfile" id="fileInput" autocomplete="off">
    </div>

    <div class="tab-panel" data-panel="paste">
      <textarea name="logtext" id="textInput" autocomplete="off"
        placeholder="Wklej zawartość logu (np. z journalctl, /var/log/syslog, itp.)…"></textarea>
    </div>

    <div style="display:flex; gap:1rem; flex-wrap:wrap; align-items:center; margin-top:1rem;">
      <input type="text" name="host" id="hostInput" placeholder="host (opcjonalnie)"
             autocomplete="off"
             title="Nazwa hosta, z którego pochodzi log. Jeśli puste — wyciągniemy z treści.">
      <span id="modelStatus" style="font-size:.85em; color:#6b7280;">
        <span class="status-dot status-offline"></span>ładowanie modeli…
      </span>
      <select name="model" id="modelSelect">
        <option value="">⏳ ładowanie…</option>
      </select>
      <button class="btn" type="submit" id="submitBtn">Skanuj</button>
      <span class="spinner" id="spin">⏳ analizuję… (pierwsze wywołanie modelu 30–60 s)</span>
    </div>
  </form>
</div>

<div class="card">
  <div class="chart-header">
    <h2>Rozkład ważności</h2>
    <div class="chart-scope" id="chartScope">Zakres: <b>wszystkie skany</b></div>
  </div>
  <div class="chart-wrap">
    <canvas id="chart"></canvas>
  </div>
  <div style="text-align:center; margin-top:.5rem;">
    <button class="btn secondary small" id="resetChart" style="display:none;">
      ← Pokaż wszystkie
    </button>
  </div>
</div>

<div class="card" id="detailCard" style="display:none;">
  <div class="chart-header">
    <h2 id="detailTitle">Szczegóły skanu</h2>
    <a class="btn small" id="detailPdf" href="#" target="_blank">📄 PDF tego skanu</a>
  </div>

  <h3>Podsumowanie AI</h3>
  <div class="summary-box" id="detailSummary">—</div>

  <h3>Wykryte problemy</h3>
  <ul class="findings-list" id="detailFindings"><li>—</li></ul>

  <h3>✅ Co sprawdzić / jak naprawić</h3>
  <ol class="reco-list" id="detailReco"><li>—</li></ol>

  <h3>💬 Zapytaj o ten skan</h3>
  <div class="chat-box">
    <div class="chat-log" id="chatLog">
      <div class="chat-empty">
        Zadaj pytanie o ten skan — np. „jak to naprawić?”, „co to za błąd?”,
        „pokaż komendę do sprawdzenia”.
      </div>
    </div>
    <div class="chat-input-row">
      <input type="text" id="chatInput" placeholder="Twoje pytanie…"
             autocomplete="off"
             onkeydown="if(event.key==='Enter'){event.preventDefault();sendChat();}">
      <button class="btn" id="chatSend" onclick="sendChat()">Wyślij</button>
      <button class="btn secondary small" onclick="clearChat()" title="Wyczyść historię">🗑️</button>
    </div>
    <div class="chat-status" id="chatStatus"></div>
  </div>
</div>

<div class="card">
  <h2>Ostatnie skany</h2>
  <a class="btn" href="export_pdf.php">📄 Pobierz raport PDF (wszystkie)</a>
  <table id="scans">
    <thead><tr>
      <th>ID</th><th>Host</th><th>Plik</th><th>Data</th><th>Model</th>
      <th>Waga</th><th>Błędów</th><th>Podsumowanie</th><th>PDF</th><th></th>
    </tr></thead>
    <tbody></tbody>
  </table>
</div>

<div class="toast" id="toast"></div>

<script>
const $ = (s) => document.querySelector(s);
let currentScanId = null;
let chatScanId = null;

/* --- Zakładki --- */
document.querySelectorAll('.tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
    tab.classList.add('active');
    document.querySelector(`.tab-panel[data-panel="${tab.dataset.tab}"]`)
      .classList.add('active');
  });
});

/* --- Wtyczka: liczba w środku donuta --- */
const centerTextPlugin = {
  id: 'centerText',
  afterDraw(chart) {
    const { ctx, chartArea } = chart;
    if (!chartArea) return;
    const total = chart.data.datasets[0].data.reduce((a, b) => a + b, 0);
    const x = (chartArea.left + chartArea.right) / 2;
    const y = (chartArea.top + chartArea.bottom) / 2;
    ctx.save();
    ctx.font = 'bold 26px system-ui, sans-serif';
    ctx.fillStyle = '#111';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(total, x, y - 8);
    ctx.font = '12px system-ui, sans-serif';
    ctx.fillStyle = '#6b7280';
    ctx.fillText('zdarzeń', x, y + 14);
    ctx.restore();
  }
};
Chart.register(centerTextPlugin);

/* --- Toast --- */
function toast(msg, ms = 3500) {
  const t = $('#toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(window._toastTimer);
  window._toastTimer = setTimeout(() => t.classList.remove('show'), ms);
}

/* --- Modele --- */
async function loadModels() {
  const sel  = $('#modelSelect');
  const stat = $('#modelStatus');
  try {
    const r = await fetch('models.php', { cache: 'no-store' });
    const data = await r.json();
    sel.innerHTML = '';
    const entries = Object.entries(data.models);
    if (entries.length === 0) {
      sel.innerHTML = '<option value="">❌ brak modeli</option>';
      return;
    }
    for (const [id, label] of entries) {
      const o = document.createElement('option');
      o.value = id; o.textContent = label;
      if (id === data.default) o.selected = true;
      sel.appendChild(o);
    }
    stat.innerHTML = data.online
      ? '<span class="status-dot status-online"></span>' + entries.length + ' modeli'
      : '<span class="status-dot status-offline"></span>Ollama offline';
  } catch (e) {
    sel.innerHTML = '<option value="">❌ błąd pobierania modeli</option>';
    stat.innerHTML = '<span class="status-dot status-offline"></span>błąd';
  }
}

/* --- Reset formularza (po odświeżeniu nic nie zostaje) --- */
function resetForm(keepModel = true) {
  const form = $('#uploadForm');
  const currentModel = $('#modelSelect').value;
  form.reset();
  $('#textInput').value = '';
  $('#fileInput').value = '';
  $('#hostInput').value = '';
  if (keepModel && currentModel) $('#modelSelect').value = currentModel;
  document.querySelectorAll('.tab').forEach(t =>
    t.classList.toggle('active', t.dataset.tab === 'file'));
  document.querySelectorAll('.tab-panel').forEach(p =>
    p.classList.toggle('active', p.dataset.panel === 'file'));
}

/* --- Upload --- */
$('#uploadForm').addEventListener('submit', async e => {
  e.preventDefault();
  const fd = new FormData(e.target);
  const activeTab = document.querySelector('.tab.active').dataset.tab;

  if (activeTab === 'file') {
    if (!$('#fileInput').files.length) { toast('Wybierz plik'); return; }
    fd.delete('logtext');
  } else {
    const text = $('#textInput').value.trim();
    if (!text) { toast('Wklej tekst logu'); return; }
    fd.delete('logfile');
  }

  const spin = $('#spin');
  const btn  = $('#submitBtn');
  spin.style.display = 'inline';
  btn.disabled = true;
  btn.textContent = 'Skanuję…';

  try {
    const r = await fetch('upload.php', { method:'POST', body: fd });
    const j = await r.json();
    if (j.error) {
      toast('Błąd: ' + j.error, 5000);
    } else {
      toast(`✅ Zapisano skan #${j.id} — ${j.severity} (${j.errors_count} zdarzeń)`);
      currentScanId = j.id;
      loadScans();
    }
  } catch (err) {
    toast('Błąd sieci: ' + err, 5000);
  } finally {
    spin.style.display = 'none';
    btn.disabled = false;
    btn.textContent = 'Skanuj';
    resetForm(true);
  }
});

/* --- Lista skanów --- */
async function loadScans() {
  try {
    const r = await fetch('api_scans.php', { cache: 'no-store' });
    const data = await r.json();
    const tbody = $('#scans tbody');
    tbody.innerHTML = '';
    (data.list || []).forEach(s => {
      const tr = document.createElement('tr');
      tr.dataset.id = s.id;
      if (currentScanId === s.id) tr.classList.add('selected');
      tr.innerHTML = `
        <td>${s.id}</td>
        <td><span class="host-tag">${escapeHtml(s.host ?? '—')}</span></td>
        <td>${escapeHtml(s.filename)}</td>
        <td>${escapeHtml(s.scan_time)}</td>
        <td><span class="model-tag">${escapeHtml(s.model ?? '—')}</span></td>
        <td class="sev-${s.severity}">${s.severity}</td>
        <td>${s.errors_count ?? 0}</td>
        <td>${escapeHtml((s.summary ?? '').slice(0, 140))}</td>
        <td><a href="export_pdf.php?id=${s.id}" target="_blank"
               onclick="event.stopPropagation()">PDF</a></td>
        <td><a href="#" class="trash" title="Usuń skan"
               onclick="event.stopPropagation(); deleteScan(${s.id}); return false;">🗑️</a></td>`;
      tr.addEventListener('click', () => selectScan(s.id));
      tbody.appendChild(tr);
    });

    if (currentScanId !== null) {
      await loadScanDetail(currentScanId);
    } else {
      drawChart(data.bySeverity || []);
    }
  } catch (e) { console.error(e); }
}

/* --- Kasowanie skanu --- */
async function deleteScan(id) {
  if (!confirm(`Usunąć skan #${id}? Tej operacji nie można cofnąć.`)) return;
  try {
    const fd = new FormData();
    fd.append('id', id);
    const r = await fetch('delete_scan.php', { method: 'POST', body: fd });
    const j = await r.json();
    if (j.error) { toast('Błąd: ' + j.error, 5000); return; }
    toast(`🗑️ Usunięto skan #${id}`);
    if (currentScanId === id) {
      currentScanId = null;
      chatScanId = null;
      $('#resetChart').style.display = 'none';
      $('#chartScope').innerHTML = 'Zakres: <b>wszystkie skany</b>';
      $('#detailCard').style.display = 'none';
    }
    loadScans();
  } catch (e) { toast('Błąd: ' + e, 5000); }
}

/* --- Wybór skanu --- */
async function selectScan(id) {
  currentScanId = id;
  document.querySelectorAll('#scans tbody tr').forEach(tr => {
    tr.classList.toggle('selected', Number(tr.dataset.id) === id);
  });
  $('#resetChart').style.display = 'inline-block';
  await loadScanDetail(id);
}

async function loadScanDetail(id) {
  try {
    const r = await fetch('api_scans.php?id=' + id, { cache: 'no-store' });
    const data = await r.json();
    if (data.error) throw new Error(data.error);
    const d = data.detail;

    $('#chartScope').innerHTML =
      `Zakres: <b>skan #${d.id}</b> &nbsp;·&nbsp; ` +
      `<span class="host-tag">${escapeHtml(d.host ?? '—')}</span> &nbsp;·&nbsp; ` +
      `${escapeHtml(d.filename)}`;

    drawChart(data.bySeverity || []);

    $('#detailCard').style.display = 'block';
    $('#detailTitle').textContent = `Skan #${d.id} — ${d.filename} [${d.severity}]`;
    $('#detailPdf').href = 'export_pdf.php?id=' + d.id;
    $('#detailSummary').textContent = d.summary || '—';

    const findings = (d.findings || '').split('\n').filter(x => x.trim());
    $('#detailFindings').innerHTML = findings.length
      ? findings.map(f => `<li>${escapeHtml(f)}</li>`).join('')
      : '<li>—</li>';

    const reco = (d.recommendations || '').split('\n').filter(x => x.trim());
    $('#detailReco').innerHTML = reco.length
      ? reco.map(r => `<li>${escapeHtml(r)}</li>`).join('')
      : '<li>Brak rekomendacji.</li>';

    // Wczytaj czat dla tego skanu
    loadChat(d.id);
  } catch (e) { console.error(e); }
}

$('#resetChart').addEventListener('click', async () => {
  currentScanId = null;
  chatScanId = null;
  $('#resetChart').style.display = 'none';
  $('#detailCard').style.display = 'none';
  $('#chartScope').innerHTML = 'Zakres: <b>wszystkie skany</b>';
  document.querySelectorAll('#scans tbody tr').forEach(tr => tr.classList.remove('selected'));
  const r = await fetch('api_scans.php', { cache: 'no-store' });
  drawChart((await r.json()).bySeverity || []);
});

/* --- Wykres --- */
function drawChart(rows) {
  const canvas = document.getElementById('chart');
  if (!canvas) return;
  if (window._chart) { window._chart.destroy(); window._chart = null; }

  if (!rows || rows.length === 0 || rows.every(r => !r.c)) {
    const ctx = canvas.getContext('2d');
    const w = canvas.clientWidth || 300;
    const h = canvas.clientHeight || 300;
    canvas.width = w; canvas.height = h;
    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = '#9ca3af';
    ctx.font = '14px system-ui, sans-serif';
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText('brak danych', w / 2, h / 2);
    return;
  }

  const colorMap = {
    'CRITICAL': '#dc2626', 'WARNING': '#d97706', 'INFO': '#16a34a',
    'HIGH':     '#dc2626', 'MEDIUM':  '#d97706', 'LOW':  '#16a34a',
  };

  window._chart = new Chart(canvas, {
    type: 'doughnut',
    data: {
      labels: rows.map(r => r.severity),
      datasets: [{
        data: rows.map(r => r.c),
        backgroundColor: rows.map(r => colorMap[r.severity] || '#9ca3af'),
        borderWidth: 2, borderColor: '#fff',
      }]
    },
    options: {
      responsive: true, maintainAspectRatio: false, cutout: '62%',
      plugins: {
        legend: { position: 'bottom',
                  labels: { boxWidth: 14, padding: 10, font: { size: 13 } } },
        tooltip: { callbacks: { label: (c) => ` ${c.label}: ${c.parsed}` } }
      },
      layout: { padding: 8 }
    }
  });
}

/* ================================================================
   CZAT PER SKAN
   ================================================================ */
async function loadChat(scanId) {
  chatScanId = scanId;
  const log = $('#chatLog');
  log.innerHTML = '<div class="chat-empty">Ładowanie historii…</div>';
  $('#chatStatus').textContent = '';
  $('#chatStatus').classList.remove('error');

  try {
    const r = await fetch('chat_history.php?scan_id=' + scanId, { cache: 'no-store' });
    const data = await r.json();
    log.innerHTML = '';
    if (!data.messages || data.messages.length === 0) {
      log.innerHTML = '<div class="chat-empty">' +
        'Zadaj pytanie o ten skan — np. „jak to naprawić?”, „co to za błąd?”, ' +
        '„pokaż komendę do sprawdzenia”.</div>';
      return;
    }
    data.messages.forEach(m => appendChatMessage(m.role, m.content));
    log.scrollTop = log.scrollHeight;
  } catch (e) {
    log.innerHTML = '<div class="chat-empty">Błąd wczytywania historii.</div>';
  }
}

function appendChatMessage(role, content) {
  const log = $('#chatLog');
  const empty = log.querySelector('.chat-empty');
  if (empty) empty.remove();
  const div = document.createElement('div');
  div.className = 'chat-msg ' + role;
  div.textContent = content;
  log.appendChild(div);
  log.scrollTop = log.scrollHeight;
  return div;
}

async function sendChat() {
  const input = $('#chatInput');
  const msg = input.value.trim();
  if (!msg || !chatScanId) return;

  input.value = '';
  input.disabled = true;
  $('#chatSend').disabled = true;
  $('#chatStatus').textContent = '⏳ model myśli…';
  $('#chatStatus').classList.remove('error');

  appendChatMessage('user', msg);
  const typing = appendChatMessage('typing', 'pisze…');

  try {
    const fd = new FormData();
    fd.append('scan_id', chatScanId);
    fd.append('message', msg);
    const r = await fetch('chat.php', { method: 'POST', body: fd });
    const data = await r.json();
    typing.remove();
    if (data.error) {
      $('#chatStatus').textContent = 'Błąd: ' + data.error;
      $('#chatStatus').classList.add('error');
      return;
    }
    appendChatMessage('assistant', data.reply);
    $('#chatStatus').textContent = '';
  } catch (e) {
    typing.remove();
    $('#chatStatus').textContent = 'Błąd sieci: ' + e;
    $('#chatStatus').classList.add('error');
  } finally {
    input.disabled = false;
    $('#chatSend').disabled = false;
    input.focus();
  }
}

async function clearChat() {
  if (!chatScanId) return;
  if (!confirm('Wyczyścić historię czatu dla tego skanu?')) return;
  const fd = new FormData();
  fd.append('scan_id', chatScanId);
  try {
    const r = await fetch('delete_chat.php', { method: 'POST', body: fd });
    const j = await r.json();
    if (j.error) { toast('Błąd: ' + j.error, 5000); return; }
    $('#chatLog').innerHTML = '<div class="chat-empty">Historia wyczyszczona.</div>';
    $('#chatStatus').textContent = '';
  } catch (e) { toast('Błąd: ' + e, 5000); }
}

/* --- Util --- */
function escapeHtml(s) {
  return String(s ?? '').replace(/[&<>"']/g, c => ({
    '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
  })[c]);
}

/* --- Start --- */
resetForm(true);

loadModels();
loadScans();
setInterval(() => { if (currentScanId === null) loadScans(); }, 15000);
</script>
</body>
</html>
