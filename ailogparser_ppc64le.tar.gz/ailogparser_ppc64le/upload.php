<?php
require __DIR__ . '/db.php';
require __DIR__ . '/ollama.php';

$cfg = require __DIR__ . '/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(400);
    exit(json_encode(['error' => 'POST required']));
}

$model = $_POST['model'] ?? $cfg['model'];
$available = ollama_list_models();
if (!empty($available) && !array_key_exists($model, $available)) {
    http_response_code(400);
    exit(json_encode(['error' => "Unknown model: $model"]));
}

$content  = '';
$filename = '';
$host     = trim($_POST['host'] ?? '');

$pasted = trim($_POST['logtext'] ?? '');

if ($pasted !== '') {
    $content  = $pasted;
    $filename = 'pasted_' . date('Ymd_His') . '.log';
    $safe = $filename;
    $dest = rtrim($cfg['upload_dir'], '/') . '/' . $safe;
    if (!is_dir($cfg['upload_dir'])) @mkdir($cfg['upload_dir'], 0775, true);
    @file_put_contents($dest, $content);
} elseif (!empty($_FILES['logfile']) && $_FILES['logfile']['error'] === UPLOAD_ERR_OK) {
    $f = $_FILES['logfile'];
    $safe = preg_replace('/[^A-Za-z0-9._-]/', '_', basename($f['name']));
    $dest = rtrim($cfg['upload_dir'], '/') . '/' . $safe;
    if (!is_dir($cfg['upload_dir'])) @mkdir($cfg['upload_dir'], 0775, true);
    if (!move_uploaded_file($f['tmp_name'], $dest)) {
        http_response_code(500);
        exit(json_encode(['error' => 'Cannot save file to ' . $dest]));
    }
    $content  = file_get_contents($dest);
    $filename = $safe;
} else {
    http_response_code(400);
    exit(json_encode(['error' => 'No file or logtext provided']));
}

if ($host === '') $host = trim($_SERVER['HTTP_X_HOST'] ?? '');
if ($host === '' && $filename !== '') {
    if (preg_match('/^([a-zA-Z0-9._-]+?)[_.\-]/', $filename, $m)) $host = $m[1];
}
if ($host === '' || $host === 'unknown') {
    $head = mb_substr($content, 0, 8192);
    if (preg_match('/^[A-Z][a-z]{2}\s+\d{1,2}\s+\d{2}:\d{2}:\d{2}\s+([a-zA-Z0-9._-]+)/m', $head, $m)) {
        $host = $m[1];
    }
}
if ($host === '') $host = 'unknown';

try {
    $filter = filter_log_errors($content, 1);
    $filteredText = implode("\n", $filter['lines']);

    if (empty($filter['lines'])) {
        $parsed = [
            'summary'         => 'No errors or warnings detected in the log.',
            'critical'        => 0, 'warning' => 0, 'info' => 0,
            'findings'        => [],
            'recommendations' => [],
        ];
    } else {
        $prompt = "Pre-filtered log (only errors/warnings/important events):\n\n"
                . mb_substr($filteredText, 0, $cfg['max_log_bytes']);

        $raw    = ollama_chat($prompt, $model);
        $parsed = parse_scan_result($raw);

        $quick = quick_severity_scan($filter['lines']);
        if ($parsed['critical'] === 0 && $quick['critical'] > 0) $parsed['critical'] = $quick['critical'];
        if ($parsed['warning']  === 0 && $quick['warning']  > 0) $parsed['warning']  = $quick['warning'];
        if ($parsed['info']     === 0 && $quick['info']     > 0) $parsed['info']     = $quick['info'];
        if ($parsed['critical'] + $parsed['warning'] + $parsed['info'] === 0) {
            $parsed['critical'] = $quick['critical'];
            $parsed['warning']  = $quick['warning'];
            $parsed['info']     = $quick['info'];
        }
    }

    $severity = $parsed['critical'] > 0 ? 'HIGH'
              : ($parsed['warning'] > 0  ? 'MEDIUM'
              : 'LOW');

    $stmt = db()->prepare("
        INSERT INTO scans
          (filename, host, scan_time, status, severity, model,
           errors_count, critical_count, warning_count, info_count,
           summary, findings, recommendations)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    $stmt->execute([
        $filename,
        $host,
        date('c'),
        'completed',
        $severity,
        $model,
        $parsed['critical'] + $parsed['warning'] + $parsed['info'],
        $parsed['critical'],
        $parsed['warning'],
        $parsed['info'],
        $parsed['summary'],
        implode("\n", $parsed['findings']),
        implode("\n", $parsed['recommendations']),
    ]);

    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'ok'              => true,
        'id'              => (int) db()->lastInsertId(),
        'file'            => $filename,
        'host'            => $host,
        'model'           => $model,
        'severity'        => $severity,
        'errors_count'    => $parsed['critical'] + $parsed['warning'] + $parsed['info'],
        'critical_count'  => $parsed['critical'],
        'warning_count'   => $parsed['warning'],
        'info_count'      => $parsed['info'],
        'lines_total'     => $filter['total_lines'],
        'lines_kept'      => count($filter['lines']),
        'summary'         => $parsed['summary'],
        'findings'        => $parsed['findings'],
        'recommendations' => $parsed['recommendations'],
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['error' => $e->getMessage(), 'file' => $filename]);
}
