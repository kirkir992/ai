<?php
require __DIR__ . '/ollama.php';
header('Content-Type: application/json; charset=utf-8');

$cfg = require __DIR__ . '/config.php';
$cacheFile = sys_get_temp_dir() . '/ollama_models_cache.json';
$ttl = $cfg['models_cache_ttl'];

$models = null;

// 1. Cache
if (file_exists($cacheFile) && (time() - filemtime($cacheFile)) < $ttl) {
    $cached = json_decode(file_get_contents($cacheFile), true);
    if (is_array($cached) && !empty($cached)) {
        $models = $cached;
    }
}

// 2. Świeże zapytanie do Ollama
if ($models === null) {
    $models = ollama_list_models();
    if (!empty($models)) {
        @file_put_contents($cacheFile, json_encode($models));
    }
}

// 3. Fallback — Ollama niedostępna
$online = !empty($models);
if (!$online) {
    $models = [
        $cfg['model'] => $cfg['model'] . ' (offline, domyślny)',
    ];
}

echo json_encode([
    'online'  => $online,
    'default' => $cfg['model'],
    'models'  => $models,
]);
