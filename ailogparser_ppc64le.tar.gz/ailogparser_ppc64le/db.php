<?php
function db(): PDO {
    static $pdo = null;
    if ($pdo) return $pdo;

    $cfg = require __DIR__ . '/config.php';
    $pdo = new PDO('sqlite:' . $cfg['db_path']);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

    $pdo->exec("CREATE TABLE IF NOT EXISTS scans (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        filename TEXT NOT NULL,
        host TEXT,
        scan_time TEXT NOT NULL,
        status TEXT NOT NULL,
        severity TEXT,
        model TEXT,
        errors_count INTEGER DEFAULT 0,
        critical_count INTEGER DEFAULT 0,
        warning_count INTEGER DEFAULT 0,
        info_count INTEGER DEFAULT 0,
        summary TEXT,
        findings TEXT,
        recommendations TEXT
    )");

    $cols = $pdo->query("PRAGMA table_info(scans)")->fetchAll(PDO::FETCH_COLUMN, 1);
    $wanted = [
        'host'            => 'TEXT',
        'model'           => 'TEXT',
        'errors_count'    => 'INTEGER DEFAULT 0',
        'critical_count'  => 'INTEGER DEFAULT 0',
        'warning_count'   => 'INTEGER DEFAULT 0',
        'info_count'      => 'INTEGER DEFAULT 0',
        'summary'         => 'TEXT',
        'recommendations' => 'TEXT',
    ];
    foreach ($wanted as $col => $type) {
        if (!in_array($col, $cols, true)) {
            $pdo->exec("ALTER TABLE scans ADD COLUMN $col $type");
        }
    }
    return $pdo;
}
