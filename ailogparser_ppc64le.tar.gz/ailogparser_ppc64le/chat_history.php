<?php
require __DIR__ . '/db.php';
header('Content-Type: application/json; charset=utf-8');

$scanId = (int)($_GET['scan_id'] ?? 0);
if ($scanId <= 0) {
    http_response_code(400);
    exit(json_encode(['error' => 'scan_id required']));
}

// Utwórz tabelę jeśli nie istnieje
db()->exec("CREATE TABLE IF NOT EXISTS chat_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    scan_id INTEGER NOT NULL,
    role TEXT NOT NULL,
    content TEXT NOT NULL,
    created_at TEXT NOT NULL
)");

$stmt = db()->prepare("SELECT role, content, created_at
                       FROM chat_messages
                       WHERE scan_id = ?
                       ORDER BY id ASC");
$stmt->execute([$scanId]);
echo json_encode(['messages' => $stmt->fetchAll()]);
