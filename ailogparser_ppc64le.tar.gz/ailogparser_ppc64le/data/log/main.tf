terraform {
  backend "http" {} # Wykorzystuje GitLab-managed Terraform state
  required_providers {
    aws = { source = "hashicorp/aws", version = "~> 5.0" }
  }
}

provider "aws" {
  region = var.aws_region
}

resource "aws_instance" "linux_server" {
  ami           = "ami-0c94855ba95c71c99" # Przykład dla Amazon Linux 2023
  instance_type = "t2.micro"

  tags = {
    Name = "GitLab-Terraform-Instance"
  }
}
