<?php

function ollama_chat(string $prompt, string $model): string {
    $cfg = require __DIR__ . '/config.php';

    $payload = [
        'model'    => $model,
        'messages' => [
            ['role' => 'system', 'content' =>
                "You are a senior Linux/SRE security analyst. You receive PRE-FILTERED log lines " .
                "(only errors, warnings and important events). Return a concise report in this EXACT format:\n" .
                "SUMMARY: <one paragraph, max 3 sentences>\n" .
                "CRITICAL: <number>\n" .
                "WARNING: <number>\n" .
                "INFO: <number>\n" .
                "FINDINGS:\n" .
                "- <short finding>\n" .
                "- <short finding>\n" .
                "RECOMMENDATIONS:\n" .
                "- <concrete step to fix or investigate issue #1 (mention commands, files or config keys)>\n" .
                "- <concrete step #2>\n" .
                "Rules: FINDINGS describe WHAT is wrong; RECOMMENDATIONS describe HOW to fix or verify it. " .
                "Be concrete, do not speculate."
            ],
            ['role' => 'user', 'content' => $prompt],
        ],
        'stream'  => false,
        'options' => ['temperature' => 0.2],
    ];

    $ch = curl_init($cfg['ollama_url']);
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
        CURLOPT_TIMEOUT        => $cfg['request_timeout'],
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_POSTFIELDS     => json_encode($payload),
    ]);

    $resp = curl_exec($ch);
    if ($resp === false) {
        $err = curl_error($ch);
        throw new RuntimeException('Ollama connection error: ' . $err);
    }
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    // curl_close() USUNIĘTE — deprecated w PHP 8.5, nic nie robi od PHP 8.0

    if ($code !== 200) {
        throw new RuntimeException("Ollama HTTP $code: " . substr($resp, 0, 300));
    }
    $data = json_decode($resp, true);
    if (!is_array($data)) {
        throw new RuntimeException('Ollama: invalid JSON response');
    }
    return $data['message']['content'] ?? '';
}

function ollama_list_models(): array {
    $cfg = require __DIR__ . '/config.php';

    $ch = curl_init($cfg['ollama_api'] . '/api/tags');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 5,
        CURLOPT_CONNECTTIMEOUT => 3,
    ]);
    $resp = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    // curl_close() USUNIĘTE

    if ($resp === false || $code !== 200) return [];
    $data = json_decode($resp, true);
    if (!is_array($data) || empty($data['models'])) return [];

    $out = [];
    foreach ($data['models'] as $m) {
        $name = $m['name'] ?? '';
        if ($name === '') continue;
        $params = $m['details']['parameter_size'] ?? '';
        $gb     = isset($m['size']) ? round($m['size'] / 1024 / 1024 / 1024, 1) : 0;
        $label  = $name;
        if ($params !== '' || $gb > 0) {
            $label .= sprintf(' (%s%s%.1f GB)',
                $params, $params !== '' ? ', ' : '', $gb);
        }
        $out[$name] = $label;
    }
    ksort($out);
    return $out;
}

function filter_log_errors(string $content, int $contextLines = 1): array {
    $lines = preg_split('/\r?\n/', $content);
    $errRe = '/\b(' .
        'error|err|fail(ed|ure)?|fatal|critical|panic|segfault|oom-killer|' .
        'denied|refused|timeout|timed out|unreachable|abort(ed)?|' .
        'exception|traceback|corrupt|invalid|unable to|cannot|' .
        'not found|no such|missing|broken|reset|dropped|' .
        'warn(ing)?|deprecated|skipped|ignored' .
    ')\b/i';

    $keep  = [];
    $count = 0;
    foreach ($lines as $i => $line) {
        if (preg_match($errRe, $line)) {
            $count++;
            for ($j = max(0, $i - $contextLines);
                 $j <= min(count($lines) - 1, $i + $contextLines); $j++) {
                $keep[$j] = true;
            }
        }
    }
    ksort($keep);

    $filtered = [];
    $prevIdx  = -2;
    foreach (array_keys($keep) as $idx) {
        if ($idx - $prevIdx > 1 && $prevIdx >= 0) {
            $filtered[] = '... (' . ($idx - $prevIdx - 1) . ' lines skipped)';
        }
        $filtered[] = $lines[$idx];
        $prevIdx = $idx;
    }
    return [
        'lines'       => $filtered,
        'total_lines' => count($lines),
        'error_lines' => $count,
    ];
}

function quick_severity_scan(array $filteredLines): array {
    $p = ['critical' => 0, 'warning' => 0, 'info' => 0];
    foreach ($filteredLines as $line) {
        if (preg_match('/\b(critical|panic|fatal|segfault|oom-killer|kernel panic)\b/i', $line)) {
            $p['critical']++;
        } elseif (preg_match('/\b(error|failed|failure|timeout|refused|denied|exception|unable to|cannot|not found)\b/i', $line)) {
            $p['warning']++;
        } elseif (preg_match('/\b(warning|warn|deprecated|skipped|ignored)\b/i', $line)) {
            $p['info']++;
        }
    }
    return $p;
}

function parse_scan_result(string $raw): array {
    $out = [
        'summary'         => '',
        'critical'        => 0,
        'warning'         => 0,
        'info'            => 0,
        'findings'        => [],
        'recommendations' => [],
    ];

    if (preg_match('/SUMMARY:\s*(.+?)(?:\n[A-Z]+:|\z)/is', $raw, $m)) {
        $out['summary'] = trim($m[1]);
    }
    if (preg_match('/CRITICAL:\s*(\d+)/i', $raw, $m)) $out['critical'] = (int)$m[1];
    if (preg_match('/WARNING:\s*(\d+)/i',  $raw, $m)) $out['warning']  = (int)$m[1];
    if (preg_match('/INFO:\s*(\d+)/i',     $raw, $m)) $out['info']     = (int)$m[1];

    if (preg_match('/FINDINGS:\s*(.+?)(?:\nRECOMMENDATIONS:|\z)/is', $raw, $m)) {
        foreach (preg_split('/\r?\n/', $m[1]) as $line) {
            $line = trim(preg_replace('/^[-*•]\s*/', '', $line));
            if ($line !== '') $out['findings'][] = $line;
        }
    }
    if (preg_match('/RECOMMENDATIONS:\s*(.+)/is', $raw, $m)) {
        foreach (preg_split('/\r?\n/', $m[1]) as $line) {
            $line = trim(preg_replace('/^[-*•]\s*/', '', $line));
            if ($line !== '') $out['recommendations'][] = $line;
        }
    }
    if (empty($out['findings'])) {
        $out['findings'][] = mb_substr($raw, 0, 1500);
    }
    if ($out['summary'] === '') {
        $out['summary'] = $out['findings'][0] ?? '';
    }
    if (empty($out['recommendations'])) {
        foreach (preg_split('/\r?\n/', $raw) as $line) {
            $line = trim($line);
            if (preg_match('/^(check|verify|inspect|review|update|install|restart|reconfigure|ensure|monitor|consider)\b/i', $line)) {
                $out['recommendations'][] = $line;
            }
        }
    }
    return $out;
}
/**
 * Wywołanie czatu z dowolnym kontekstem (bez filtra).
 * Używane przez chat.php do rozmowy o konkretnym skanie.
 */
function ollama_chat_with_context(string $systemContext, string $userMessage, string $model): string {
    $cfg = require __DIR__ . '/config.php';

    $payload = [
        'model'    => $model,
        'messages' => [
            ['role' => 'system', 'content' => $systemContext],
            ['role' => 'user',   'content' => $userMessage],
        ],
        'stream'  => false,
        'options' => ['temperature' => 0.3],
    ];

    $ch = curl_init($cfg['ollama_url']);
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
        CURLOPT_TIMEOUT        => $cfg['request_timeout'],
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_POSTFIELDS     => json_encode($payload),
    ]);

    $resp = curl_exec($ch);
    if ($resp === false) {
        throw new RuntimeException('Ollama connection error: ' . curl_error($ch));
    }
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    if ($code !== 200) {
        throw new RuntimeException("Ollama HTTP $code: " . substr($resp, 0, 300));
    }
    $data = json_decode($resp, true);
    if (!is_array($data)) {
        throw new RuntimeException('Ollama: invalid JSON response');
    }
    return $data['message']['content'] ?? '';
}
