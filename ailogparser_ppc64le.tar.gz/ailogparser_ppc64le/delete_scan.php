<?php
require __DIR__ . '/db.php';
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit(json_encode(['error' => 'POST required']));
}

$id = (int)($_POST['id'] ?? 0);
if ($id <= 0) {
    http_response_code(400);
    exit(json_encode(['error' => 'Missing id']));
}

$cfg = require __DIR__ . '/config.php';

$stmt = db()->prepare("SELECT filename FROM scans WHERE id = ?");
$stmt->execute([$id]);
$row = $stmt->fetch();

if (!$row) {
    http_response_code(404);
    exit(json_encode(['error' => 'Not found']));
}

db()->prepare("DELETE FROM scans WHERE id = ?")->execute([$id]);

$stillUsed = db()->prepare("SELECT COUNT(*) FROM scans WHERE filename = ?");
$stillUsed->execute([$row['filename']]);
if ((int)$stillUsed->fetchColumn() === 0) {
    $path = rtrim($cfg['upload_dir'], '/') . '/' . $row['filename'];
    if (is_file($path)) @unlink($path);
}

echo json_encode(['ok' => true, 'deleted_id' => $id]);
