<?php
require __DIR__ . '/db.php';
require __DIR__ . '/ollama.php';

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit(json_encode(['error' => 'POST required']));
}

$scanId  = (int)($_POST['scan_id'] ?? 0);
$message = trim($_POST['message'] ?? '');
$model   = trim($_POST['model'] ?? '');

if ($scanId <= 0 || $message === '') {
    http_response_code(400);
    exit(json_encode(['error' => 'scan_id and message required']));
}

// Pobierz skan (kontekst dla modelu)
$stmt = db()->prepare("SELECT * FROM scans WHERE id = ?");
$stmt->execute([$scanId]);
$scan = $stmt->fetch();
if (!$scan) {
    http_response_code(404);
    exit(json_encode(['error' => 'Scan not found']));
}

$cfg = require __DIR__ . '/config.php';
if ($model === '') $model = $scan['model'] ?: $cfg['model'];

// Zbuduj kontekst — to co model już "wie" o skanie
$context = "You are an assistant for a security log analysis tool. " .
           "The user is asking follow-up questions about a specific scan. " .
           "Answer concisely and concretely — mention commands, files, config keys. " .
           "Base your answer ONLY on the scan data below and general Linux/SRE knowledge.\n\n" .
           "=== SCAN DATA ===\n" .
           "Scan ID: {$scan['id']}\n" .
           "Host: " . ($scan['host'] ?? '—') . "\n" .
           "File: {$scan['filename']}\n" .
           "Date: {$scan['scan_time']}\n" .
           "Severity: " . ($scan['severity'] ?? '—') . "\n" .
           "Model used for scan: " . ($scan['model'] ?? '—') . "\n" .
           "Counts: CRITICAL=" . (int)$scan['critical_count'] .
                ", WARNING=" . (int)$scan['warning_count'] .
                ", INFO=" . (int)$scan['info_count'] . "\n\n" .
           "Summary:\n" . ($scan['summary'] ?? '—') . "\n\n" .
           "Findings:\n" . ($scan['findings'] ?? '—') . "\n\n" .
           "Recommendations:\n" . ($scan['recommendations'] ?? '—') . "\n" .
           "=== END SCAN DATA ===\n";

try {
    $reply = ollama_chat_with_context($context, $message, $model);

    // Opcjonalnie zapisujemy do historii
    try {
        db()->exec("CREATE TABLE IF NOT EXISTS chat_messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            scan_id INTEGER NOT NULL,
            role TEXT NOT NULL,
            content TEXT NOT NULL,
            created_at TEXT NOT NULL
        )");
        $ins = db()->prepare("INSERT INTO chat_messages (scan_id, role, content, created_at)
                              VALUES (?, ?, ?, ?)");
        $ins->execute([$scanId, 'user',      $message, date('c')]);
        $ins->execute([$scanId, 'assistant', $reply,   date('c')]);
    } catch (Throwable $e) {
        // historia to bonus — nie przerywamy z jej powodu
    }

    echo json_encode([
        'ok'      => true,
        'reply'   => $reply,
        'model'   => $model,
        'scan_id' => $scanId,
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
