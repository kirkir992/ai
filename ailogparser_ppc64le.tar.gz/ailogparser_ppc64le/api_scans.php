<?php
require __DIR__ . '/db.php';
header('Content-Type: application/json; charset=utf-8');

$cfg = require __DIR__ . '/config.php';

// Backfill hosta dla starych rekordów
$needsBackfill = (int) db()->query(
    "SELECT COUNT(*) FROM scans WHERE host IS NULL OR host = ''"
)->fetchColumn();

if ($needsBackfill > 0) {
    $rows = db()->query(
        "SELECT id, filename FROM scans WHERE host IS NULL OR host = ''"
    )->fetchAll();
    $upd = db()->prepare("UPDATE scans SET host = ? WHERE id = ?");

    foreach ($rows as $r) {
        $host = 'unknown';
        $path = rtrim($cfg['upload_dir'], '/') . '/' . $r['filename'];
        if (is_readable($path)) {
            $head = @file_get_contents($path, false, null, 0, 8192);
            if ($head && preg_match(
                '/^[A-Z][a-z]{2}\s+\d{1,2}\s+\d{2}:\d{2}:\d{2}\s+([a-zA-Z0-9._-]+)/m',
                $head, $m
            )) {
                $host = $m[1];
            }
        }
        if ($host === 'unknown' &&
            preg_match('/^([a-zA-Z0-9._-]+?)[_.\-]/', $r['filename'], $m)) {
            $host = $m[1];
        }
        $upd->execute([$host, $r['id']]);
    }
}

// Tryb szczegółu
if (!empty($_GET['id'])) {
    $stmt = db()->prepare("SELECT * FROM scans WHERE id = ?");
    $stmt->execute([(int)$_GET['id']]);
    $row = $stmt->fetch();
    if (!$row) {
        http_response_code(404);
        exit(json_encode(['error' => 'Not found']));
    }
    echo json_encode([
        'detail' => $row,
        'bySeverity' => [
            ['severity' => 'CRITICAL', 'c' => (int)$row['critical_count']],
            ['severity' => 'WARNING',  'c' => (int)$row['warning_count']],
            ['severity' => 'INFO',     'c' => (int)$row['info_count']],
        ],
    ]);
    exit;
}

// Tryb listy
$list = db()->query("
    SELECT id, filename, host, scan_time, severity, model,
           errors_count, critical_count, warning_count, info_count, summary
    FROM scans
    ORDER BY id DESC
    LIMIT 50
")->fetchAll();

$agg = db()->query("
    SELECT
      COALESCE(SUM(critical_count),0) AS crit,
      COALESCE(SUM(warning_count),0)  AS warn,
      COALESCE(SUM(info_count),0)     AS info
    FROM scans
")->fetch();

echo json_encode([
    'list' => $list,
    'bySeverity' => [
        ['severity' => 'CRITICAL', 'c' => (int)$agg['crit']],
        ['severity' => 'WARNING',  'c' => (int)$agg['warn']],
        ['severity' => 'INFO',     'c' => (int)$agg['info']],
    ],
]);
